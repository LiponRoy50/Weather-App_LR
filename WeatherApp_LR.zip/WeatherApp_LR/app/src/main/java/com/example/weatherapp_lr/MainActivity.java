package com.example.weatherapp_lr;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    TextView tv_1,tv_2,tv_3,tv_4,tv_5;
    Button btn;
    EditText CityName;

    RequestQueue MYrequestQueue ;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv_1 = findViewById(R.id.resut_Condition);
        tv_2 = findViewById(R.id.resut_Date);
        tv_3 = findViewById(R.id.resut_Humudity);
        tv_4 = findViewById(R.id.resut_Presser);
        tv_5 = findViewById(R.id.resut_Tempture);

        btn = findViewById(R.id.searchButton);
        CityName=findViewById(R.id.cityName);





        MYrequestQueue = MySingleton.getInstance(this).getRequestQueue();

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                My_Json_Data();

            }
        });

    }



    public void My_Json_Data() {

        String City = CityName.getText().toString();

      // URL ="https://openweathermap.org/data/2.5/weather?q="+City+"&appid==b6907d289e10d714a6e88b30761fae22";

       String URL ="https://openweathermap.org/data/2.5/weather?q="+City+"&appid=b6907d289e10d714a6e88b30761fae22";

        JsonObjectRequest Jor =new JsonObjectRequest(Request.Method.GET, URL, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {
                    JSONArray jsonArray= response.getJSONArray("weather");
                    JSONObject weather_Object =jsonArray.getJSONObject(0);
                    String Desc = weather_Object.getString("description");

                     JSONObject main_Object1 =response.getJSONObject("main");
                     String Temp =String.valueOf(main_Object1.getDouble("temp"));
                     String pressure =String.valueOf(main_Object1.getDouble("pressure"));
                     String humidity =String.valueOf(main_Object1.getDouble("humidity"));





                    // for Current Date
                    Calendar calendar =Calendar.getInstance();
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEE=MM-dd");
                    String dateMe =simpleDateFormat.format(calendar.getTime());
                    // End current date

                    tv_1.setText("Condition : "+Desc);
                    tv_2.setText("Date : " +dateMe);
                    tv_3.setText("Humidity : " +humidity+" hpa");
                    tv_4.setText("Pressure : " +pressure+" %");
                    tv_5.setText("Tempture : " +"%.2f"+Temp+" C");



                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                error.printStackTrace();



            }
        });

        MYrequestQueue.add(Jor);


    }



 // End of class

}
